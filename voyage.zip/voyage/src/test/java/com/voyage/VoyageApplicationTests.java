package com.voyage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VoyageApplicationTests {

	@Test
	void contextLoads() {
	}

}

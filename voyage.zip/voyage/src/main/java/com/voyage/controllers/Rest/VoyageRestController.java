package com.voyage.controllers.Rest;

import com.voyage.entites.Voyage;
import com.voyage.service.VoyageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/rest-voyages") // 📌 Préfixe REST
public class VoyageRestController {

    @Autowired
    private VoyageService voyageService;

    // ✅ GET /rest-voyages/findAll → Tous les voyages
    @GetMapping("/findAll")
    public ResponseEntity<List<Voyage>> findAllVoyages() {
        List<Voyage> voyages = voyageService.getAllVoyages();
        return ResponseEntity.ok(voyages);
    }

    // ✅ GET /rest-voyages/findById/{id} → Voyage par ID
    @GetMapping("/findById/{id}")
    public ResponseEntity<Voyage> getVoyageById(@PathVariable Long id) {
        return voyageService.getVoyageById(id)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // ✅ POST /rest-voyages/create → Ajouter un voyage
    @PostMapping("/create")
    public ResponseEntity<Voyage> createVoyage(@RequestBody Voyage voyage) {
        Voyage savedVoyage = voyageService.createVoyage(voyage); // ✅ nom cohérent
        return ResponseEntity.ok(savedVoyage);
    }

    // ✅ PUT /rest-voyages/update/{id} → Modifier un voyage
    @PutMapping("/update/{id}")
    public ResponseEntity<Voyage> updateVoyage(@PathVariable Long id, @RequestBody Voyage voyageDetails) {
        Optional<Voyage> voyageOptional = voyageService.getVoyageById(id);
        if (voyageOptional.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        Voyage voyageToUpdate = voyageOptional.get();
        voyageToUpdate.setDestination(voyageDetails.getDestination());
        voyageToUpdate.setDateDepart(voyageDetails.getDateDepart());
        voyageToUpdate.setDateRetour(voyageDetails.getDateRetour());
        voyageToUpdate.setPrix(voyageDetails.getPrix());
        voyageToUpdate.setAvion(voyageDetails.getAvion());

        Voyage updatedVoyage = voyageService.createVoyage(voyageToUpdate); // ✅ appel cohérent
        return ResponseEntity.ok(updatedVoyage);
    }

    // ✅ DELETE /rest-voyages/delete/{id} → Supprimer
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> deleteVoyage(@PathVariable Long id) {
        voyageService.deleteVoyage(id);
        return ResponseEntity.noContent().build();
    }
}

package com.voyage.controllers;

import com.voyage.entites.Voyage;
import com.voyage.entites.Avion;
import com.voyage.service.VoyageService;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Optional;

@Controller
@RequestMapping("/voyages")
public class VoyageController {

    @Autowired
    private VoyageService voyageService;

    @PersistenceContext
    private EntityManager entityManager;

    // 🔹 Liste des voyages
    @GetMapping
    public String listVoyages(Model model) {
        model.addAttribute("voyages", voyageService.getAllVoyages());
        return "list-voyages";
    }

    // 🔹 Formulaire d'ajout
    @GetMapping("/new")
    public String showCreateForm() {
        return "add-voyage";
    }

    // 🔹 Enregistrement d’un nouveau voyage
    @PostMapping("/save")
    public String saveVoyage(
            @RequestParam String destination,
            @RequestParam String dateDepart,
            @RequestParam String dateRetour,
            @RequestParam Double prix,
            @RequestParam Long avionId
    ) {
        try {
            Avion avion = entityManager.find(Avion.class, avionId);
            if (avion == null) {
                throw new IllegalArgumentException("⚠️ Avion avec ID " + avionId + " introuvable.");
            }

            LocalDate depart = LocalDate.parse(dateDepart);
            LocalDate retour = LocalDate.parse(dateRetour);

            Voyage voyage = new Voyage();
            voyage.setDestination(destination);
            voyage.setDateDepart(depart);
            voyage.setDateRetour(retour);
            voyage.setPrix(prix);
            voyage.setAvion(avion);

            voyageService.createVoyage(voyage);
            return "redirect:/voyages";

        } catch (DateTimeParseException e) {
            System.err.println("⚠️ Erreur de format de date : " + e.getMessage());
        } catch (Exception e) {
            System.err.println("❌ Erreur lors de l'enregistrement du voyage : " + e.getMessage());
        }

        return "error"; // crée une page error.html si besoin
    }

    // 🔹 Suppression
    @GetMapping("/delete/{id}")
    public String deleteVoyage(@PathVariable Long id) {
        voyageService.deleteVoyage(id);
        return "redirect:/voyages";
    }

    // 🔹 Formulaire de modification
    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        Optional<Voyage> voyage = voyageService.getVoyageById(id);
        if (voyage.isPresent()) {
            model.addAttribute("voyage", voyage.get());
            return "edit-voyage";
        } else {
            return "redirect:/voyages";
        }
    }

    // 🔹 Mise à jour
    @PostMapping("/update/{id}")
    public String updateVoyage(
            @PathVariable Long id,
            @RequestParam String destination,
            @RequestParam String dateDepart,
            @RequestParam String dateRetour,
            @RequestParam Double prix,
            @RequestParam Long avionId
    ) {
        try {
            Avion avion = entityManager.find(Avion.class, avionId);
            if (avion == null) {
                throw new IllegalArgumentException("⚠️ Avion avec ID " + avionId + " introuvable.");
            }

            LocalDate depart = LocalDate.parse(dateDepart);
            LocalDate retour = LocalDate.parse(dateRetour);

            Voyage voyage = new Voyage();
            voyage.setId(id);
            voyage.setDestination(destination);
            voyage.setDateDepart(depart);
            voyage.setDateRetour(retour);
            voyage.setPrix(prix);
            voyage.setAvion(avion);

            voyageService.createVoyage(voyage);
            return "redirect:/voyages";

        } catch (Exception e) {
            System.err.println("❌ Erreur lors de la mise à jour : " + e.getMessage());
            return "error";
        }
    }
}

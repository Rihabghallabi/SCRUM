package com.voyage.service;

import com.voyage.entites.Voyage;

import java.util.List;
import java.util.Optional;

public interface VoyageService {
    List<Voyage> getAllVoyages();

    Optional<Voyage> getVoyageById(Long id);

    Voyage createVoyage(Voyage voyage); // ✅ nom cohérent avec le contrôleur

    void deleteVoyage(Long id);
}

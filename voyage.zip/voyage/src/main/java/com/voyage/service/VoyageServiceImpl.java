package com.voyage.service;

import com.voyage.entites.Voyage;
import com.voyage.repositories.VoyageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class VoyageServiceImpl implements VoyageService {

    @Autowired
    private VoyageRepository voyageRepository;

    @Override
    public List<Voyage> getAllVoyages() {
        return voyageRepository.findAll();
    }

    @Override
    public Optional<Voyage> getVoyageById(Long id) {
        return voyageRepository.findById(id);
    }

    @Override
    public Voyage createVoyage(Voyage voyage) {
        return voyageRepository.save(voyage);
    }

    @Override
    public void deleteVoyage(Long id) {
        voyageRepository.deleteById(id);
    }
}

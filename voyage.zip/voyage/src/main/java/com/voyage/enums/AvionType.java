package com.voyage.enums;

public enum AvionType {
    COMMERCIAL,
    CARGO,
    PRIVE
}

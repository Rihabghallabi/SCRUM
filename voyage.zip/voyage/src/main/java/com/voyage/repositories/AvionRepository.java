// AvionRepository.java
package com.voyage.repositories;

import com.voyage.entites.Avion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AvionRepository extends JpaRepository<Avion, Long> {}

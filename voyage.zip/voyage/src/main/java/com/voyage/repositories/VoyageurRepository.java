// VoyageurRepository.java
package com.voyage.repositories;

import com.voyage.entites.Voyageur;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VoyageurRepository extends JpaRepository<Voyageur, Long> {}
